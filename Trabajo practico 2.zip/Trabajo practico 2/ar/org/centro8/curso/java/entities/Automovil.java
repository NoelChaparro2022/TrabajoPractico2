package ar.org.centro8.curso.java.entities;

public class Automovil extends Vehiculo {

    private String puertas;

    public Automovil(String marca, String modelo, String puertas, double precio) {

        super(marca, modelo, precio);
        this.puertas = puertas;

    }

    @Override
    public String toString() {
        return "Marca: " + getMarca() + " // Modelo: " + getModelo() + " // puertas: " + getPuertas()
                + " // Precio: " + getPrecioFormat();
    }

    public String getPuertas() {
        return puertas;
    }

}
