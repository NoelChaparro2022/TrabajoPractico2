package ar.org.centro8.curso.java.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import ar.org.centro8.curso.java.entities.Automovil;
import ar.org.centro8.curso.java.entities.Moto;
import ar.org.centro8.curso.java.entities.Vehiculo;

public class TestVehiculo {

        public static void main(String[] args) {

                separador();

                List<Vehiculo> list = new ArrayList<>();
                list.add(new Automovil("Peugeot", "206", "4", 200000.0));
                list.add(new Moto("Honda", "Titan", "125c", 60000.0));
                list.add(new Automovil("Peugeot", "208", "5", 250000.0));
                list.add(new Moto("Yamaha", "YBR ", "160c", 80500.5));

                cargarLista(list);
                separador();
                System.out.print("Vehiculo más caro: ");
                vehiculoMasCaro(list);
                System.out.print("Vehiculo más barato: ");
                vehiculoMasBarato(list);
                System.out.print("Vehículo que contiene en el modelo la letra 'Y': ");
                vehiculoconletraY(list);
                separador();
                System.out.println("Vehículos ordenados por precio de mayor a menor:");
                ordenMayoryMenor(list);
                separador();
                System.out.println("Vehículos ordenados por orden natural ");
                ordenNatural(list);
        }

        private static void cargarLista(List<Vehiculo> list) {
                for (Vehiculo v : list) {
                        System.out.println(v);
                }
        }

        private static void vehiculoMasCaro(List<Vehiculo> list) {
                double caro = list
                                .stream()
                                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();
                list
                                .stream()
                                .filter(p -> p.getPrecio() == caro)
                                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
        }

        private static void vehiculoMasBarato(List<Vehiculo> list) {
                double barato = list
                                .stream()
                                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();
                list
                                .stream()
                                .filter(p -> p.getPrecio() == barato)
                                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));

        }

        private static void vehiculoconletraY(List<Vehiculo> list) {

                list
                                .stream()
                                .filter(v -> v.getMarca().contains("Y"))
                                .forEach(v -> System.out
                                                .println(v.getMarca() + " " + v.getModelo() + " "
                                                                + v.getPrecio()));
        }

        private static void ordenMayoryMenor(List<Vehiculo> list) {
                list
                                .stream()
                                .sorted(Comparator.comparing(Vehiculo::getPrecio).reversed())
                                .forEach(a -> System.out.println(a.getMarca() + " " + a.getModelo()));
        }

        private static void ordenNatural(List<Vehiculo> list) {

                list
                                .stream()
                                .sorted()
                                .forEach(System.out::println);

        }

        private static void separador() {
                System.out.println("---------------------------------------------");

        }

}