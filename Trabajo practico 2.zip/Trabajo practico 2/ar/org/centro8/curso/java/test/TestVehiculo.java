package ar.org.centro8.curso.java.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import ar.org.centro8.curso.java.entities.Automovil;
import ar.org.centro8.curso.java.entities.Moto;
import ar.org.centro8.curso.java.entities.Vehiculo;

public class TestVehiculo {

        public static void main(String[] args) {

                separador();

                // cargando lista
                cargarLista();
                List<Vehiculo> list = new ArrayList<>();

                list.add(new Automovil("Peugeot", "206", "4", 200000.00d));

                list.add(new Moto("Honda", "Titan", "125c", 60000.00d));

                list.add(new Automovil("Peugeot", "208", "5", 250000.00d));

                list.add(new Moto("Yamaha", "YBR", "160c", 80500.50d));
                list.forEach(System.out::println);

                separador();

                // cargando el vehiculo mas caro
                vehiculoMasCaro();
                double caro = list
                                .stream()
                                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();
                list
                                .stream()
                                .filter(p -> p.getPrecio() == caro)
                                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
                separador();
                // cargando el vehiculo mas barato
                vehiculoMasBarato();
                double barato = list
                                .stream()
                                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();
                list
                                .stream()
                                .filter(p -> p.getPrecio() == barato)
                                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));

                // cargando el vehiculo con letra Y
                vehiculoconletraY();
                list
                                .stream()
                                .filter(v -> v.getMarca().contains("Y"))
                                .forEach(v -> System.out
                                                .println(v.getMarca() + " " + v.getModelo() + " "
                                                                + v.getPrecio()));

                separador();

                // los vehiculos ordenados por precio mayor a menor
                ordenMayoryMenor();
                list
                                .stream()
                                .sorted(Comparator.comparing(Vehiculo::getPrecio))
                                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));

                separador();

                // los vehiculos por orden natural
                ordenNatural();
                list
                                .stream()
                                .sorted()
                                .forEach(System.out::println);

        }

        private static void separador() {
                System.out.println("---------------------------------------------");

        }

        private static void cargarLista() {
                System.out.println("cargando lista de autos:  ");

        }

        private static void vehiculoMasCaro() {
                System.out.print("\nVehiculo más caro: ");
        }

        private static void vehiculoMasBarato() {

                System.out.print("Vehiculo más barato: ");
        }

        private static void vehiculoconletraY() {

                System.out.print("Vehiculo que contiene en el modelo la letra ´Y´: ");
        }

        private static void ordenMayoryMenor() {

                System.out.println("\nVehiculos ordenados por precio de mayor a menor: ");
        }

        private static void ordenNatural() {

                System.out.println("\nVehiculos ordenados por orden natural: ");
        }
}